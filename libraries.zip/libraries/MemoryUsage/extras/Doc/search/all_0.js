var searchData=
[
  ['freeram_5fprint',['FREERAM_PRINT',['../MemoryUsage_8h.html#adec45170b247de0a4de89412b4e9a2af',1,'MemoryUsage.h']]],
  ['freeram_5fprint_5ftext',['FREERAM_PRINT_TEXT',['../MemoryUsage_8h.html#ab39be25c638fdea7fc1e506e8a643e2a',1,'MemoryUsage.h']]]
];
